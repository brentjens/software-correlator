###!/usr/bin/env python2

from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
import numpy

ext_modules = [
    Extension(
        "lofarlive.nearfield",
        ["lofarlive/nearfield.pyx"],
        extra_compile_args=['-fopenmp'],
        extra_link_args=['-fopenmp'],
       	include_dirs=[numpy.get_include()],
    )
]

setup(name         = 'lofarlive',
      version      = '0.1',
      description  = 'Near real time display of LOFAR images',
      author       = 'Michiel Brentjens',
      author_email = 'brentjens@astron.nl',
      url          = '',
      scripts      = ['scripts/lofarlive-record', 'scripts/lofarlive-transfer'],
      packages     = ['lofarlive'],
      requires     = ['numpy', 'scipy', 'matplotlib', 'nose', 'coverage',
                      'numpydoc', 'sphinx'],
      ext_modules = cythonize(ext_modules)
    )
