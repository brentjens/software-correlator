import os, sys, time, gc, signal, subprocess, glob
from numpy import arange, array, complex128, conj, dot, exp, fromfile
from numpy import median, meshgrid, newaxis, ones, pi, sqrt, transpose
from numpy import zeros, integer, float64, complex64, float32, sin, cos, linspace
from numpy.linalg import norm
from lofarlive.antennafield import parse_antenna_field, parse_ihbadeltas
from pylab import draw, imshow, title, xticks, yticks, ion, ioff, show, clf

from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.backend_bases import FigureCanvasBase

import lofarlive.astrometry as astrometry
from lofarantpos.db import LofarAntennaDatabase

import lofarlive.nearfield as nf

import logging
import ephem

class MissingCalTableError(RuntimeError):
    r'''
    Raised when no appropriate calibration table was found.
    '''
    pass



def rcus_in_station(station_type):
    r'''
    Returns the number of RCUs in a station, given its type.

    **Parameters**

    station_type : string
        The kind of station that produced the correlation. Choose one
        of 'core', 'remote', 'intl'.

    **Examples**

    >>> rcus_in_station('core')
    96
    >>> rcus_in_station('remote')
    96
    >>> rcus_in_station('intl')
    192
    >>> rcus_in_station('burp')
    Traceback (most recent call last):
    ...
    KeyError: 'burp'

    '''
    return {'core': 96, 'remote': 96, 'intl': 192}[station_type]






def read_acm_cube(filename, station_type):
    r'''
    **Parameters**

    filename : string
        The file containing the array correlation matrix.

    station_type : string
        The kind of station that produced the correlation. Choose one
        of 'core', 'remote', 'intl'.

    **Returns**

    A 3D cube of complex numbers, where the indices are [time slots, rcu, rcu].

    **Examples**

    >>> cube = read_acm_cube('test/DE602C/sb296/20120109_232258_xst.dat', 'intl')
    >>> cube.shape
    (4, 192, 192)
    '''
    num_rcu    = rcus_in_station(station_type)
    data       = fromfile(filename, dtype = complex128)
    time_slots = int(len(data)/num_rcu/num_rcu)
    return data.reshape((time_slots, num_rcu, num_rcu))



def subband_freq_hz(subband, band, clock_hz = 200e6):
    r'''
    Computes the central frequency of a given subband number.

    **Parameters**

    subband : int
        Subband number in the range [0, 511]

    band : string
        One of 'LBA', 'HBA_LOW', 'HBA_MID', or 'HBA_HIGH'

    clock_hz : float
        The observation's sample frequency in Hz. Either
        200e6 or 160e6.

    **Examples**

    >>> subband_freq_hz(256, 'LBA', clock_hz = 200e6)
    50000000.0
    >>> subband_freq_hz(256, 'LBA', clock_hz = 160e6)
    40000000.0
    >>> subband_freq_hz(128, 'HBA_LOW', clock_hz = 200e6)
    125000000.0
    >>> subband_freq_hz(128, 'HBA_MID', clock_hz = 160e6)
    180000000.0
    >>> subband_freq_hz(128, 'HBA_HIGH', clock_hz = 200e6)
    225000000.0
    '''
    bands = {'LBA': 0.0, 'HBA_LOW': 100e6, 'HBA_MID': 160e6, 'HBA_HIGH': 200e6}
    f0_hz = bands[band]
    return float(subband)/512.0*clock_hz/2.0 + f0_hz
    


def read_caltable(field_name, rcu_mode, config_dir = 'globaldata/lofarlive', num_subbands = 512):
    r'''
    Reads a station's calibration table.

    **Parameters**

    field_name : string
        The name of the antenna field, for example 'DE602LBA'

    rcu_mode : integer
        The receiver mode for which the calibration table is
        requested. An integer from 1 to 7 inclusive.

    config_dir : string
        Root directory under which station information is stored in
        subdirectories DE602C/etc/, RS106/etc/,...

    num_subbands : integer
        Number of subbands in the station polyphase filter. Use 512
        for LOFAR.

    **Returns**

    A tuple containing a list of strings representing the header
    lines, and a 2D numpy.array of complex numbers representing the
    station gain coefficients.

    **Examples**

    >>> header_lines, cal_data = read_caltable('DE602LBA', rcu_mode=3, config_dir = 'test/')
    >>> print(''.join(header_lines))
    HeaderStart
    CalTableHeader.Observation.Station = DE602
    CalTableHeader.Observation.Mode = 3
    CalTableHeader.Observation.Source = all
    CalTableHeader.Observation.Date = 06-10-2012
    CalTableHeader.Calibration.Version = 5120
    CalTableHeader.Calibration.Name = eikelboom
    CalTableHeader.Calibration.Date = 16-10-2012
    CalTableHeader.Calibration.PPSDelay = [56 61 2 3 58 62 0 8 57 61 0 6 57 61 0 6 63 2 9 12 63 2 9 11 63 3 11 14 63 63 8 12 0 3 10 13 63 3 11 15 1 2 10 16 3 10 14 19 60 63 4 6 63 3 9 16 63 2 10 15 61 63 4 9 27 27 37 42 26 27 38 43 24 28 36 42 19 24 29 35 9 13 21 24 9 11 19 24 8 13 18 20 9 11 18 24 ]
    CalTableHeader.Comment = Antennas 52, 54 and 71 flagged for both polarizations
    HeaderStop
    <BLANKLINE>
    >>> cal_data.shape
    (512, 192)
    >>> cal_data[0:5, 10]
    array([ 1.03373240-0.09869793j,  1.03365487-0.0995066j ,
            1.03357671-0.10031521j,  1.03349791-0.10112376j,
            1.03341849-0.10193224j])
    >>> read_caltable('DE602LBA', rcu_mode=18, config_dir = 'test/')
    Traceback (most recent call last):
    ...
    IOError: [Errno 2] No such file or directory: 'test/DE602C/etc/CalTable_mode18.dat'

    '''
    station, field = field_name[0:5].upper(), field_name[5:].upper()
    station_number = station[2:5]
    filename       = os.path.join(config_dir, station+'C', 'etc',
                                  'CalTable_%s_mode%d.dat' % (station_number, rcu_mode))
    if not os.path.exists(filename):
        filename       = os.path.join(config_dir, station+'C', 'etc',
                                      'CalTable_mode%d.dat' % rcu_mode)
        
    header_lines = []
    infile = open(filename, 'rb')
    try: 
        while True:
            header_lines.append(infile.readline().decode('utf8'))
            if 'HeaderStop' in header_lines[-1]:
                break
    except UnicodeDecodeError:
        # No header; close and open again
        infile.close()
        infile = open(filename, 'rb')
        pass
    caldata  = fromfile(infile, dtype=complex128)
    num_rcus = len(caldata)//num_subbands
    
    return  (header_lines, caldata.reshape((num_subbands, num_rcus)))





def antenna_positions(field_name, config_dir = '/globaldata/lofarlive/'):
    r'''
    Read the antenna positions from a file and rotates them to the
    plane of the station.

    **Parameters**

    field_name : string
        Name of the station, e.g. 'DE602LBA', 'CS003HBA0', 'rs106Hba'

    config_dir : string
        Directory containing station directories named RS106C/ DE602C/, etc.

    **Examples**

    >>> pos = antenna_positions('DE602LBA', config_dir = 'test/')
    >>> pos.shape
    (192, 3)
    >>> (pos[0::2]-pos[1::2] == 0.0).all()
    True
    >>> pos[191,:]
    array([  9.92288290e+00,   8.24366512e+00,  -3.35771694e-04])
    >>> pos = antenna_positions('CS002HBA1', config_dir = 'test/')
    >>> pos[10]
    >>> pos[20]
    '''

    station, field = field_name[0:5].upper(), field_name[5:].upper()
    filename       = os.path.join(config_dir, station+'C', 'etc',
                                  'AntennaField.conf')
    
    position_info     = [info for info in parse_antenna_field(filename)
                         if info.field_name == field[:3] and
                         type(info).__name__ == 'AntennaField'][0]
    #print(position_info)

    field_for_rotmat = field
    if 'CS' in field_name.upper() and field == 'HBA':
        field_for_rotmat = 'HBA0'
    field_info_for_rotmat = [info for info in parse_antenna_field(filename)
                             if info.field_name == field_for_rotmat]
    rot_mat   = None
    positions_m = None
    for item in field_info_for_rotmat:
        if type(item).__name__ is 'RotationMatrix':
            rot_mat = item.rotation_matrix
        elif type(item).__name__ is 'AntennaField':
            positions_m = item.positions
    
    if rot_mat is None:
        for item in field_info_for_rotmat:
            if type(item).__name__ is 'RotationMatrix':
                rot_mat = item.rotation_matrix
    if rot_mat is None:
        raise ValueError('Could not find rotation matrix for '+field_name+' in '+filename)

    if positions_m is None:
        raise ValueError('Could not find antenna positions for '+field_name+' in '+filename)
    num_ant, num_pol, num_coord = positions_m.shape
    positions_m = positions_m.reshape(num_ant*num_pol, num_coord)
    positions_pqr = array([dot(transpose(rot_mat), pos_m) for pos_m in positions_m])
    return positions_pqr


def hba_element_offsets(field_name, config_dir = '/globaldata/lofarlive/'):
    r'''
    Read the hba antenna element offsets from a file and rotates them to the
    plane of the station.

    **Parameters**

    field_name : string
        Name of the station, e.g. 'DE602HBA', 'CS003HBA0', 'rs106Hba'

    config_dir : string
        Directory containing station directories named RS106C/ DE602C/, etc.

    **Examples**

    >>> pos = hba_element_offsets('DE602HBA', config_dir = 'test/')
    >>> pos.shape
    (16, 3)
    >>> pos
    array([[  6.86350864e-01,   2.56124915e+00,   3.25240000e-05],
           [  1.31112304e+00,   1.47904951e+00,  -2.54334000e-04],
           [  1.93672971e+00,   3.96015585e-01,   2.38293000e-04],
           [  2.56150188e+00,  -6.86184061e-01,  -4.85650000e-05],
           [ -3.96266719e-01,   1.93622746e+00,   3.78710000e-05],
           [  2.28505455e-01,   8.54027809e-01,  -2.48987000e-04],
           [  8.54112128e-01,  -2.29006112e-01,   2.43640000e-04],
           [  1.47888430e+00,  -1.31120576e+00,  -4.32180000e-05],
           [ -1.47888430e+00,   1.31120576e+00,   4.32180000e-05],
           [ -8.54112128e-01,   2.29006112e-01,  -2.43640000e-04],
           [ -2.28505455e-01,  -8.54027809e-01,   2.48987000e-04],
           [  3.96266719e-01,  -1.93622746e+00,  -3.78710000e-05],
           [ -2.56150188e+00,   6.86184061e-01,   4.85650000e-05],
           [ -1.93672971e+00,  -3.96015585e-01,  -2.38293000e-04],
           [ -1.31112304e+00,  -1.47904951e+00,   2.54334000e-04],
           [ -6.86350864e-01,  -2.56124915e+00,  -3.25240000e-05]])
    >>> pos = hba_element_offsets('CS002HBA1', config_dir = 'test/')
    >>> pos.shape
    (16, 3)
    >>> pos
    array([[ -1.87451230e+00,   1.87538997e+00,   6.88490000e-05],
           [ -6.24599304e-01,   1.87497614e+00,   3.29511000e-04],
           [  6.25433289e-01,   1.87535426e+00,  -8.58000000e-06],
           [  1.87534629e+00,   1.87494043e+00,   2.52082000e-04],
           [ -1.87479030e+00,   6.25279839e-01,  -3.81280000e-05],
           [ -6.24877299e-01,   6.24866006e-01,   2.22534000e-04],
           [  6.25155294e-01,   6.25244127e-01,  -1.15557000e-04],
           [  1.87506829e+00,   6.24830294e-01,   1.45105000e-04],
           [ -1.87506829e+00,  -6.24830294e-01,  -1.45105000e-04],
           [ -6.25155294e-01,  -6.25244127e-01,   1.15557000e-04],
           [  6.24877299e-01,  -6.24866006e-01,  -2.22534000e-04],
           [  1.87479030e+00,  -6.25279839e-01,   3.81280000e-05],
           [ -1.87534629e+00,  -1.87494043e+00,  -2.52082000e-04],
           [ -6.25433289e-01,  -1.87535426e+00,   8.58000000e-06],
           [  6.24599304e-01,  -1.87497614e+00,  -3.29511000e-04],
           [  1.87451230e+00,  -1.87538997e+00,  -6.88490000e-05]])

    >>> pos = hba_element_offsets('CS002HBA0', config_dir = 'test/')
    >>> pos.shape
    (16, 3)
    >>> pos
    array([[  3.23450166e-01,   2.63172380e+00,  -1.84355000e-04],
           [  1.09299134e+00,   1.64676161e+00,  -2.04457000e-04],
           [  1.86253251e+00,   6.61799426e-01,  -2.24559000e-04],
           [  2.63207368e+00,  -3.23162760e-01,  -2.44661000e-04],
           [ -6.62015526e-01,   1.86249924e+00,  -2.64967000e-04],
           [  1.07525646e-01,   8.77537057e-01,  -2.85069000e-04],
           [  8.77066818e-01,  -1.07425129e-01,  -3.05171000e-04],
           [  1.64660799e+00,  -1.09238732e+00,  -3.25273000e-04],
           [ -1.64660799e+00,   1.09238732e+00,   3.25273000e-04],
           [ -8.77066818e-01,   1.07425129e-01,   3.05171000e-04],
           [ -1.07525646e-01,  -8.77537057e-01,   2.85069000e-04],
           [  6.62015526e-01,  -1.86249924e+00,   2.64967000e-04],
           [ -2.63207368e+00,   3.23162760e-01,   2.44661000e-04],
           [ -1.86253251e+00,  -6.61799426e-01,   2.24559000e-04],
           [ -1.09299134e+00,  -1.64676161e+00,   2.04457000e-04],
           [ -3.23450166e-01,  -2.63172380e+00,   1.84355000e-04]])

    >>> pos = hba_element_offsets('CS002HBA', config_dir = 'test/')
    >>> pos.shape
    (32, 3)
    >>> pos[::2,:]
    array([[  3.23450166e-01,   2.63172380e+00,  -1.84355000e-04],
           [  1.86253251e+00,   6.61799426e-01,  -2.24559000e-04],
           [ -6.62015526e-01,   1.86249924e+00,  -2.64967000e-04],
           [  8.77066818e-01,  -1.07425129e-01,  -3.05171000e-04],
           [ -1.64660799e+00,   1.09238732e+00,   3.25273000e-04],
           [ -1.07525646e-01,  -8.77537057e-01,   2.85069000e-04],
           [ -2.63207368e+00,   3.23162760e-01,   2.44661000e-04],
           [ -1.09299134e+00,  -1.64676161e+00,   2.04457000e-04],
           [ -1.87451230e+00,   1.87538997e+00,   6.88490000e-05],
           [  6.25433289e-01,   1.87535426e+00,  -8.58000000e-06],
           [ -1.87479030e+00,   6.25279839e-01,  -3.81280000e-05],
           [  6.25155294e-01,   6.25244127e-01,  -1.15557000e-04],
           [ -1.87506829e+00,  -6.24830294e-01,  -1.45105000e-04],
           [  6.24877299e-01,  -6.24866006e-01,  -2.22534000e-04],
           [ -1.87534629e+00,  -1.87494043e+00,  -2.52082000e-04],
           [  6.24599304e-01,  -1.87497614e+00,  -3.29511000e-04]])
    
    '''

    station, field = field_name[0:5].upper(), field_name[5:].upper()
    if 'HBA' not in field.upper():
        raise ValueError('hba_element_offsets(): %s is not an HBA field.' %
                         field_name)
    filename       = os.path.join(config_dir, station+'C', 'etc',
                                  'iHBADeltas.conf')
    ihba_deltas = parse_ihbadeltas(filename)

    filename       = os.path.join(config_dir, station+'C', 'etc',
                                  'AntennaField.conf')
    field_for_rotmat = field
    if 'CS' in field_name.upper() and field == 'HBA':
        field_for_rotmat = 'HBA0'
    field_info_for_rotmat = [info for info in parse_antenna_field(filename)
                             if info.field_name == field_for_rotmat]
    rot_mat   = None
    for item in field_info_for_rotmat:
        if type(item).__name__ is 'RotationMatrix':
            rot_mat = item.rotation_matrix
    
    if rot_mat is None:
        raise ValueError('Could not find rotation matrix for '+field_name+' in '+filename)
    all_offsets = array(dot(rot_mat.T, ihba_deltas.T).T)
    if field == 'HBA0':
        return all_offsets[:16,:]
    elif field == 'HBA1':
        return all_offsets[16:,:]
    else:
        return all_offsets
    





def baseline_matrix_m(positions_m):
    r'''
    Computes all baseline pairs between the provided positions.

    **Parameters**

    positions_m : (n, 3) numpy.array of floats
        The antenna positions in meters.

    **Returns**

    An (n, n, 3) numpy.array of floats containing the matrix of
    baseline vectors. baseline_matrix_m[i, j] contains positions_m[j]
    - positions_m[i].

    **Examples**

    >>> baseline_matrix_m(array([[1, 2, 3.0], [-2, -1, 0], [3, 4, 2]]))
    array([[[ 0.,  0.,  0.],
            [-3., -3., -3.],
            [ 2.,  2., -1.]],
    <BLANKLINE>
           [[ 3.,  3.,  3.],
            [ 0.,  0.,  0.],
            [ 5.,  5.,  2.]],
    <BLANKLINE>
           [[-2., -2.,  1.],
            [-5., -5., -2.],
            [ 0.,  0.,  0.]]])
    '''
    return positions_m[newaxis, :, :] - positions_m[:, newaxis,  :]


def acm_as_vector(acm, include_diag=False):
    r'''
    Convert array correlation matrix to a vector of the upper
    triangular matrix, excluding the auto correlations.

    **Parameters**

    acm : (n, n) numpy matrix
        The matrix to unravel.

    include_diag : bool
        If True, include the on-diagonal elements.

    **Returns**

    A numpy.array containing the n*(n-1)/2 upper triangular elements
    of the acm, where consecutive rows are appended.

    **Examples**

    >>> acm_as_vector(array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]))
    array([2, 3, 6])
    >>> acm_as_vector(array([[[1, 1], [2, 2], [3, 3]],
    ...                      [[4, 4], [5, 5], [6, 6]],
    ...                      [[7, 7], [8, 8], [9, 9]]]))
    array([[2, 2],
           [3, 3],
           [6, 6]])

    >>> acm_as_vector(array([[[1, 1], [2, 2], [3, 3]],
    ...                      [[4, 4], [5, 5], [6, 6]],
    ...                      [[7, 7], [8, 8], [9, 9]]]),
    ...               include_diag=True)
    array([[1, 1],
           [2, 2],
           [3, 3],
           [5, 5],
           [6, 6],
           [9, 9]])
    '''
    upper_triangle_vector = []
    acm_list              = acm.tolist()
    offset = 1
    if include_diag:
        offset = 0
    for row_num, row in enumerate(acm_list):
        upper_triangle_vector += row[row_num+offset:]
    return array(upper_triangle_vector, dtype=acm.dtype)



def make_imaging_matrix(uvw_m, freq_hz, l_rad, m_rad,
                        min_baseline_lambda=None,
                        max_baseline_lambda=None):
    r'''
    Compute a data model matrix for use in image reconstruction
    algorithms. It assumes the following data model:
    
    .. math:: \vec{v} = \mathrm{A}\vec{x},
    
    where :math:`\vec{x}` is the image in the x,y domain we are after, and
    :math:`\vec{v}` are the observed visibilities in the l,m
    domain. Because the matrix describes the transform from x,y to l,m,
    the sign in the exponent is the opposite of *fourier_sign*. The matrix
    elements are given by
    
    .. math:: a_{ij} = \mathrm{e}^{-s 2 \pi \mathrm{i} \nu (x_i l_j + y_i m_j)/c}.
    
    
    **Parameters**
    
    uvw_m : (n, 3) numpy.array of floats
        The uvw coordinates of the baselines in m

    freq_hz : float
        The observing frequency in Hz.

    l_rad : 1D numpy.array of floats
        l coordinates of the image pixels in radians.

    m_rad : 1D numpy.array of floats
        m coordinates of the image pixels in radians.

    min_baseline_lambda: float
        Minimum baseline to use in imaging. If None: use the shortest.

    max_baseline_lambda: float
        Maximum baseline to use in imaging. If None: use longest.

    **Returns**
    
    A 2D numpy array representing the matrix :math:`\mathrm{A}`, with
    dimensions (len(FTGrid.l_rad), len(FTGrid.x_m)*len(FTGrid.y_m)).
    
    **Examples**
    
    >>> l_rad = arange(-1,+1.001, 0.5)
    >>> m_rad = arange(-1,+1.001, 0.25)
    >>> freq_hz = 59e6
    >>> uvw_m = array([[1, 2, 3.0], [-2, -1, 0], [3, 4, 2]])
    >>> mat, grid_l, grid_m = make_imaging_matrix(uvw_m, freq_hz, l_rad, m_rad)
    >>> mat.shape
    (45, 3)
    >>> mat[0]
    array([-0.84295002+0.53799188j, -0.84295002-0.53799188j,
           -0.71864955-0.69537244j])

    '''
    arg    = 2j*pi*freq_hz/299792458.0

    u_m    = array(uvw_m[:, 0], dtype=float32)[newaxis, :]
    v_m    = array(uvw_m[:, 1], dtype=float32)[newaxis, :]

    
    grid_l, grid_m = meshgrid(l_rad, m_rad)
    grid_l = array(grid_l.ravel(), dtype=float32)[:, newaxis]
    grid_m = array(grid_m.ravel(), dtype=float32)[:, newaxis]
        
    mat    = exp(arg*(u_m*grid_l + v_m*grid_m))

    uv_lambda = sqrt(u_m**2 + v_m**2)*freq_hz/299792458.0
    bl_mask = ones(u_m.shape, dtype=int)
    if min_baseline_lambda is not None:
        bl_mask *= uv_lambda >= min_baseline_lambda
    if max_baseline_lambda is not None:
        bl_mask *= uv_lambda <= max_baseline_lambda
    
    return mat.reshape((len(l_rad)*len(m_rad), len(uvw_m)))*bl_mask[newaxis,:], grid_l, grid_m



def station_type(station_name):
    r'''
    Given a station's name, return its type.

    **Parameters**

    station_name : string
        Examples: 'RS106', 'CS021', 'DE602'

    **Examples**

    >>> station_type('CS103')
    'core'
    >>> station_type('RS307')
    'remote'
    >>> station_type('DE602')
    'intl'
    
    '''
    prefix = station_name[0:2].upper()
    if  prefix == 'CS':
        return 'core'
    elif prefix == 'RS':
        return 'remote'
    else:
        return 'intl'


def compute_mapping_matrix(field_name, subband, band,
                           config_dir = '/globaldata/lofarlive/',
                           num_pixels = 101, min_baseline_lambda=None,
                           max_baseline_lambda=None):
    r'''
    min_baseline_lambda: float
        Minimum baseline to use in imaging. If None: use the shortest.

    max_baseline_lambda: float
        Maximum baseline to use in imaging. If None: use longest.

    '''
    l_rad     = (arange(num_pixels) - num_pixels/2)/abs(num_pixels/2.0)
    m_rad     = l_rad.copy()
    freq_hz   = subband_freq_hz(subband, band, clock_hz = 200e6)

    if 'CS' in field_name.upper() or 'RS' in field_name.upper():
        #print('DUTCH STATION')
        uvw_mat_m = baseline_matrix_m(antenna_positions(field_name, config_dir=config_dir)[96::2]) # LBA_OUTER
        #print(antenna_positions(field_name, config_dir=config_dir))
    else:
        #print('EU STATION')
        uvw_mat_m = baseline_matrix_m(antenna_positions(field_name, config_dir=config_dir)[0:192:2])

    uvw_m      = acm_as_vector(uvw_mat_m)
    return make_imaging_matrix(uvw_m, freq_hz, l_rad, m_rad, min_baseline_lambda, max_baseline_lambda)



def compute_hba_single_mapping_matrix(field_name, subband, band,
                                      config_dir = '/globaldata/lofarlive/',
                                      num_pixels = 201, min_baseline_lambda=None,
                                      max_baseline_lambda=None):
    r'''
    min_baseline_lambda: float
        Minimum baseline to use in imaging. If None: use the shortest.

    max_baseline_lambda: float
        Maximum baseline to use in imaging. If None: use longest.

    '''
    l_rad     = (arange(num_pixels) - num_pixels/2)/abs(num_pixels/2.0)
    m_rad     = l_rad.copy()
    freq_hz   = subband_freq_hz(subband, band, clock_hz = 200e6)
    pqr_ant_m = hba_single_element_pqr_ant_m(field_name, config_dir)
    if 'CS' in field_name.upper() or 'RS' in field_name.upper():
        print('DUTCH STATION')
        uvw_mat_m = baseline_matrix_m(pqr_ant_m) #HBA0
    else:
        print('EU STATION')
        uvw_mat_m = baseline_matrix_m(pqr_ant_m)

    uvw_m      = acm_as_vector(uvw_mat_m)
    return make_imaging_matrix(uvw_m, freq_hz, l_rad, m_rad, min_baseline_lambda, max_baseline_lambda)



def near_field_distances(pqr_ant, pqr_pixels):
    r'''
    Calculate distance to pixels from antenna positions.

    **Parameters**

    pqr_ant : numpy.array of floats
        PQR coordinates of every antenna. Indices [ant, pqr]

    pqr_pixels : numpy.array of floats
        PQR coordinates of every pixel. Indices [pixel, pqr]

    
    **Returns**

    2D numpy.array of float distances [ant, pixel]


    **Examples**
    
    >>> nfd = near_field_distances(array([[1,2,3],[-2,-3,-1],[0,-2, +4]]), array([[10,5,6],[-4,-3,-2]]))
    >>> abs(nfd - array([[  9.94987437,   8.66025404], [ 16.03121954,   2.23606798], [ 12.36931688,   7.28010989]])).max() < 1e-6
    True
    '''
    return array(norm(pqr_ant[:, newaxis, :] - pqr_pixels[newaxis, :, :], axis=-1),
                 dtype=float32)
    
        
        
def mapping_matrix_near_field(pqr_ant_m,
                              freq_hz,
                              p_m = linspace(-1000, 1000, 10),
                              q_m = linspace(-1000, 1000, 10),
                              altitude_m = 0.0,
                              phase_only=True):
    r'''
    '''
    r_m = altitude_m

    grid_p, grid_q = meshgrid(p_m, q_m)
    grid_p = array(grid_p.ravel(), dtype=float32)
    grid_q = array(grid_q.ravel(), dtype=float32)
    grid_r = array(r_m*ones(len(grid_q)), dtype=float32)
    grid_pqr = array([grid_p, grid_q, grid_r], dtype=float32).T

    pqr_ant_m = array(pqr_ant_m, dtype=float32)
    distances_pqr = near_field_distances(pqr_ant_m, grid_pqr)
    ant_gains = array(exp(2j*pi*freq_hz*distances_pqr/299792458.0), dtype=complex64)
    if not phase_only:
        ant_gains *= distances_pqr
    baseline_gains = ant_gains[:, newaxis, :]*conj(ant_gains[newaxis, :, :])
    num_ant = pqr_ant_m.shape[0]
    matrix_rows = []
    for row_id in range(num_ant):
        for col_id in range(row_id+1, num_ant):
            matrix_rows.append(baseline_gains[row_id, col_id, :])
    
    mat = array(matrix_rows, dtype=complex64).T
    mat /= abs(mat).mean(axis=0)[newaxis, :]
    return mat, grid_p, grid_q



def lba_outer_mapping_matrix_near_field(field_name, subband, band,
                                        config_dir = '/globaldata/lofarlive/',
                                        p_m = linspace(-1000, 1000, 10),
                                        q_m = linspace(-1000, 1000, 10),
                                        altitude_m = 0.0,
                                        phase_only=True):
    r'''
    '''
    if 'CS' in field_name.upper() or 'RS' in field_name.upper():
        #print('DUTCH STATION')
        pqr_ant_m = antenna_positions(field_name, config_dir=config_dir)[96::2] # LBA_OUTER
    else:
        #print('EU STATION')
        pqr_ant_m = antenna_positions(field_name, config_dir=config_dir)[0:192:2]
    pqr_ant_m = array(pqr_ant_m, dtype=float32)
    freq_hz   = array(subband_freq_hz(subband, band, clock_hz = 200e6), dtype=float32)
    return mapping_matrix_near_field(pqr_ant_m, freq_hz, p_m, q_m, altitude_m, phase_only)




def hba_single_element_pqr_ant_m(field_name, config_dir='/globaldata/lofarlive'):
    pqr_ant_m = antenna_positions(field_name, config_dir=config_dir)[::2]
    element_offsets = hba_element_offsets(field_name, config_dir=config_dir)
    hba0_offsets = element_offsets
    hba1_offsets = element_offsets
    if 'CS' in field_name.upper():
        print('CORE STATION')
        element_ids = [0, 10, 4, 3, 14, 0, 5, 5, 3, 13, 10, 3, 12, 2, 7, 15, 6, 14, 7, 5, 7, 9, 0, 15]*2
        if element_offsets.shape[0] == 32:
            hba0_offsets = element_offsets[:16, :]
            hba1_offsets = element_offsets[16:, :]
        if field in ['HBA', 'HBA0']:
            pqr_ant_m = array([pqr + element_offsets[element_ids[ant] + 16*(ant//24), :]
                               for ant, pqr in enumerate(pqr_ant_m)], dtype=float32)
        elif field == 'HBA1':
            pqr_ant_m = array([pqr + hba1_offsets[element_ids[ant+24],:]
                               for ant, pqr in enumerate(pqr_ant_m)], dtype=float32)
            
    elif 'RS' in field_name.upper():
        print('Remote station')
        element_ids = [0, 13, 12, 4, 11, 11, 7, 8, 2, 7, 11, 2, 10, 2, 6, 3, 8, 3, 1, 7, 1, 15, 13, 1,
                       11, 1, 12, 7, 10, 15, 8, 2, 12, 13, 9, 13, 4, 5, 5, 12, 5, 5, 9, 11, 15, 12, 2, 15 ]
        pqr_ant_m = array([pqr + element_offsets[element_ids[ant],:]
                           for ant, pqr in enumerate(pqr_ant_m)], dtype=float32)
    else:
        print('EU STATION')
        element_ids = [0,5,3,1,8,3,12,15,10,13,11,5,12,12,5,2,10,8,0,3,5,1,4,0,11,6,2,4,9,14,15,3,7,5,
                       13,15,5,6,5,12,15,7,1,1,14,9,4,9,3,9,3,13,7,14,7,14,2,8,8,0,1,4,2,2,12,15,5,7,6,
                       10,12,3,3,12,7,4,6,0,5,9,1,10,10,11,5,11,7,9,7,6,4,4,15,4,1,15]
        pqr_ant_m = array([pqr + element_offsets[element_ids[ant],:]
                           for ant, pqr in enumerate(pqr_ant_m)], dtype=float32)
    return pqr_ant_m




def hba_mapping_matrix_near_field(field_name, subband, band,
                                  config_dir = '/globaldata/lofarlive/',
                                  p_m = linspace(-1000, 1000, 10),
                                  q_m = linspace(-1000, 1000, 10),
                                  altitude_m = 0.0,
                                  phase_only=True):
    r'''
    '''
    station, field = field_name[0:5].upper(), field_name[5:].upper()
    pqr_ant_m = hba_single_element_pqr_ant_m(field_name, config_dir)
    freq_hz   = array(subband_freq_hz(subband, band, clock_hz = 200e6), dtype=float32)
    return mapping_matrix_near_field(pqr_ant_m, freq_hz, p_m, q_m, altitude_m, phase_only)




def near_field_image(acm, rcu_gains, field_name, subband, band, config_dir,
                     p_m, q_m, r_m):
    db = LofarAntennaDatabase()
    if 'CS' in field_name.upper() or 'RS' in field_name.upper():
        #print('DUTCH STATION')
        pqr_ant_m = db.antenna_pqr(field_name.upper())# imager.antenna_positions(field_name, config_dir=config_dir)[::2]
    else:
        #print('EU STATION')
        pqr_ant_m = db.antenna_pqr(field_name.upper())#, config_dir=config_dir)[::2]
    ant_pqr_m = array(pqr_ant_m, dtype=float32)

    rcu_gains = array(rcu_gains, dtype=complex64)
    gain_matrix = rcu_gains[newaxis, :]*conj(rcu_gains[:, newaxis])
    acm = array(acm/gain_matrix, dtype=complex64)

    vis_xx = acm_as_vector(acm[0::2, 0::2])
    vis_yy = acm_as_vector(acm[1::2, 1::2])
    num_ant = acm.shape[0]//2
    freq_hz = subband_freq_hz(subband, band, clock_hz=200e6)
    ant1_grid, ant2_grid = meshgrid(arange(num_ant, dtype=integer), arange(num_ant, dtype=integer))
    ant1 = acm_as_vector(ant1_grid)
    ant2 = acm_as_vector(ant2_grid)
    img_shape = (len(q_m), len(p_m))
    q_grid, p_grid = meshgrid(q_m, p_m)
    pqr_m = array([p_grid.ravel(),
                   q_grid.ravel(),
                   [r_m]*(img_shape[0]*img_shape[1])],
                dtype=float32).T

    xx_img = nf.phase_up_visibilities_monochromatic(pqr_m, ant_pqr_m, ant1, ant2, vis_xx, freq_hz)
    yy_img = nf.phase_up_visibilities_monochromatic(pqr_m, ant_pqr_m, ant1, ant2, vis_yy, freq_hz)
    return (xx_img+yy_img).reshape(img_shape), imshow_extent(p_grid.ravel(), q_grid.ravel(), img_shape)



def make_maps(filename, field_name, matrix, grid_l, grid_m, num_pixels, rcu_gains):
    r'''
    '''
    acm  = read_acm_cube(filename, station_type(field_name))
    gain_matrix = rcu_gains[newaxis, :]*conj(rcu_gains[:, newaxis])
    acm /= gain_matrix[newaxis,:,:]

    acm  = median(acm, axis = 0)
    
    xx   = acm[0::2, 0::2]
    yy   = acm[1::2, 1::2]

    vis_xx = acm_as_vector(xx)
    vis_yy = acm_as_vector(yy)
    bad_xx = abs(vis_xx) > 100*vis_xx.std()
    bad_yy = abs(vis_yy) > 100*vis_yy.std()
    vis_xx[bad_xx] = 0
    vis_yy[bad_yy] = 0

    image  = dot(matrix, vis_xx + vis_yy).real.reshape((num_pixels, num_pixels))
    image -= image.min()
    return image*((sqrt(grid_l**2+grid_m**2) <= (1.0+2./(num_pixels-1))).reshape((num_pixels, num_pixels)))


def make_maps_cube(filename, field_name, matrix, grid_l, grid_m, num_pixels, rcu_gains,
                   apply_mask=True, p_pixels=None, q_pixels=None):
    r'''
    '''
    acm  = array(read_acm_cube(filename, station_type(field_name)), dtype=complex64)
    if p_pixels is None:
        p_pixels = num_pixels
    if q_pixels is None:
        q_pixels = num_pixels
    rcu_gains = array(rcu_gains, dtype=complex64)
    gain_matrix = rcu_gains[newaxis, :]*conj(rcu_gains[:, newaxis])
    acm /= gain_matrix[newaxis,:,:]

    images = []
    for frame_id, acm_frame in enumerate(acm):
        xx   = acm_frame[0::2, 0::2]
        yy   = acm_frame[1::2, 1::2]
        vis_xx = acm_as_vector(xx)
        vis_yy = acm_as_vector(yy)
        bad_xx = abs(vis_xx) > 100*vis_xx.std()
        bad_yy = abs(vis_yy) > 100*vis_yy.std()
        vis_xx[bad_xx] = 0
        vis_yy[bad_yy] = 0
        image  = array(dot(matrix, vis_xx + vis_yy).real.reshape((q_pixels, p_pixels)),
                       dtype=float32)
        images.append(image)
    mask = ((sqrt(grid_l**2+grid_m**2) <= (1.0+2./(min(p_pixels, q_pixels)-1))).reshape((q_pixels, p_pixels)))
    if apply_mask:
        return array(images)*mask[newaxis,:,:]
    else:
        return array(images)
        




from lofarlive.fista import fista_matrix_fixed as fista


def make_maps_fista(filename, field_name, matrix, grid_l, grid_m, num_pixels, rcu_gains,
                    reg_factor = 5e7):
    r'''
    '''
    acm  = read_acm_cube(filename, station_type(field_name))
    acm  = median(acm, axis = 0)

    gain_matrix = rcu_gains[newaxis, :]*conj(rcu_gains[:, newaxis])
    acm /= gain_matrix

    xx   = acm[0::2, 0::2]
    yy   = acm[1::2, 1::2]

    xx_acs = abs(array([xx[i, i] for i in range(xx.shape[0])]))
    yy_acs = abs(array([yy[i, i] for i in range(yy.shape[0])]))
    xx_alive = xx_acs > median(xx_acs)*0.2
    yy_alive = yy_acs > median(yy_acs)*0.2
    xx_acm_mask_alive = xx_alive[newaxis,:]*xx_alive[:,newaxis]
    yy_acm_mask_alive = yy_alive[newaxis,:]*yy_alive[:,newaxis]
    
    vis_xx = acm_as_vector(xx)
    vis_yy = acm_as_vector(yy)
    xx_mask_alive = acm_as_vector(xx_acm_mask_alive)
    yy_mask_alive = acm_as_vector(yy_acm_mask_alive)
    bad_xx = abs(vis_xx) > 100*vis_xx.std()
    bad_yy = abs(vis_yy) > 100*vis_yy.std()
    vis_xx[bad_xx] = 0
    vis_yy[bad_yy] = 0

    model_matrix = conj(transpose(matrix))

    image_vector_xx = fista(model_matrix*xx_mask_alive[:, newaxis],
                            vis_xx,
                            epsilon=1e-6,
                            max_iter=20,
                            x0=zeros((num_pixels*num_pixels), dtype=float64),
                            reg_factor=reg_factor,
                            require_positivity=True,
                            output_is_real=True, verbose=True,
                            lfactor=5.0)
    image_vector_yy = fista(model_matrix*yy_mask_alive[:, newaxis],
                            vis_yy,
                            epsilon=1e-6,
                            max_iter=20,
                            x0=zeros((num_pixels*num_pixels), dtype=float64),
                            reg_factor=reg_factor,
                            require_positivity=True,
                            output_is_real=True, verbose=True,
                            lfactor=5.0)
                         
                         
    
    return (image_vector_xx+image_vector_yy).reshape((num_pixels, num_pixels))*((sqrt(grid_l**2+grid_m**2) <= (1.0+2./(num_pixels-1))).reshape((num_pixels, num_pixels)))





def make_maps_fista_cubes(filename, field_name, matrix, grid_l, grid_m, num_pixels, rcu_gains,
                          reg_factor = 5e7):
    r'''
    '''
    acm  = read_acm_cube(filename, station_type(field_name))

    gain_matrix = rcu_gains[newaxis, :]*conj(rcu_gains[:, newaxis])
    acm /= gain_matrix[newaxis,:,:]
    model_matrix = conj(transpose(matrix))


    images = []
    for acm_frame in acm:
        xx   = acm_frame[0::2, 0::2]
        yy   = acm_frame[1::2, 1::2]
        vis_xx = acm_as_vector(xx)
        vis_yy = acm_as_vector(yy)
        bad_xx = abs(vis_xx) > 100*vis_xx.std()
        bad_yy = abs(vis_yy) > 100*vis_yy.std()
        vis_xx[bad_xx] = 0
        vis_yy[bad_yy] = 0

        image_vector_xx = fista(model_matrix, vis_xx,
                                epsilon=1e-6, max_iter=20,
                                x0=zeros((num_pixels*num_pixels), dtype=float64),
                                reg_factor=reg_factor,
                                require_positivity=True,
                                output_is_real=True, verbose=True,
                                lfactor=5.0)
        image_vector_yy = fista(model_matrix, vis_yy,
                                epsilon=1e-6, max_iter=20,
                                x0=zeros((num_pixels*num_pixels), dtype=float64),
                                reg_factor=reg_factor,
                                require_positivity=True,
                                output_is_real=True, verbose=True,
                                lfactor=5.0)
        
        image = (image_vector_xx+image_vector_yy).reshape((num_pixels, num_pixels))
        images.append(image)
    mask = ((sqrt(grid_l**2+grid_m**2) <= (1.0+2./(num_pixels-1))).reshape((num_pixels, num_pixels)))
    return array(images)*mask[newaxis,:,:]






    

def lofar_live(dir_name, field_name, subband, band, num_pixels = 101):
    r'''
    '''
    mat, grid_l, grid_m  = compute_mapping_matrix(field_name, subband, band, num_pixels=num_pixels, config_dir='antenna-fields')
    print(mat.shape)
    print(grid_l, grid_m)
    while True:
        for filename in sorted(os.listdir(dir_name))[-10:-1]:
            try:
                print(filename)
                clf()
                gc.collect(True)
                filename_full = os.path.join(dir_name, filename)
                img = make_maps(filename_full, field_name, mat, grid_l, grid_m, num_pixels)
                max_flux = img.max()
                print(max_flux)
                print(img.shape)
                imshow(img[:, ::-1], origin = 'lower')
                title('LOFAR LIVE at '+field_name+' '+filename.split('_xst.dat')[0]+' UTC', fontsize=45)
                xticks([])
                yticks([])
                draw()
                #time.sleep(0.1)
            except ValueError:
                print(str(sys.exc_info()[1]))
                pass
        time.sleep(2.0)



def imshow_extent(grid_l, grid_m, shape):
    r'''
    '''
    l = grid_l.reshape(shape)
    m = grid_m.reshape(shape)
    return (l[ 0,  0] - 0.5*(l[ 0,  1] - l[ 0,  0]),
            l[ 0, -1] - 0.5*(l[ 0, -2] - l[ 0, -1]),
            m[ 0,  0] - 0.5*(m[ 1,  0] - m[ 0,  0]),
            m[-1,  0] - 0.5*(m[-2,  0] - m[-1,  0]))
            



def add_source_labels(ax, field_name, date, config_dir):
    r'''
    '''
    sun = ephem.Sun()
    observer = ephem.Observer()
    observer.date = ephem.Date(date)
    sun.compute(observer)

    sources = [['Cyg A', 5.23368246693, 0.710940478253],
               ['Cas A', 6.12348768062, 1.02651539956],
               #['Sgr A*', 4.64985098985, -0.506281802989],
               ['Sun', float(sun.ra), float(sun.dec)],
               ['Tau A', 1.45967266776, 0.38422550818],
               ['Vir A', 3.27608651711, 0.216265899703],
               ['Her A', 4.41191600524, 0.0871355629058],
               ['Per A', 0.871803604172, 0.724515761167]]
    

    station, field = field_name[0:5].upper(), field_name[5:].upper()
    filename       = os.path.join(config_dir, station+'C', 'etc',
                                  'AntennaField.conf')
    field_info     = [info for info in parse_antenna_field(filename)
                      if info.field_name == field]

    rot_mat   = None
    for item in field_info:
        if type(item).__name__ is 'RotationMatrix':
            rot_mat = item.rotation_matrix
    if rot_mat is None:
        raise ValueError('Could not find rotation matrix for '+field_name+' in '+filename)
    
    to_local = transpose(rot_mat)
    
    for source in sources:
        label, ra, dec = tuple(source)
        itrf           = astrometry.itrf_from_topo_ra_dec(ra, dec, date)
        lmn            = dot(to_local, itrf)
        if lmn[-1] > 0.0:
            ax.text(-lmn[0]+0.05, lmn[1]+0.05, label, fontsize=20, color='white')
    return ax

def check_output(args, stderr = None, execute = True, timeout_s = None):
    r'''
    Call an external program with command line arguments, and return
    its output as a byte string.

    **Parameters**

    args : list of strings
        The command and its argument as a list of strings.

    stderr : None or subprocess.STDOUT
        If None: ignore stderr output, if subprocess.STDOUT, redirect
        standard error output to standard output.

    execute : bool
        If True, execute the command. If False, just log the command
        line and return an empty string without executing the command.

    timeout_s : None or float
        If None: wait until child process terminates. If a float: wait
        for at most ``timeout_s`` seconds for the child to
        terminate. If the chilkd does not terminate within the set
        time out, kill the child process with SIGTERM and raise a
        RuntimeError.

    **Returns**

    A string containing all of the program output.

    **Examples**

    >>> check_output(['ls', '-d', '.'], execute = False)
    ''
    >>> check_output(['ls', '-d', '.'])
    '.\n'
    >>> check_output(['sleep', '2'], timeout_s = 3.0)
    ''
    >>> check_output(['sleep', '2'], timeout_s = 1.0)
    Traceback (most recent call last):
    ...
    RuntimeError: sleep 2 killed with signal 15; output:
    ''

    ``slowoutput`` writes five characters per second:
    
    >>> check_output(['test/slowoutput.py', 'short'], timeout_s =1.5)
    'short'
    >>> check_output(['test/slowoutput.py', 'a', 'longish string', 'that interestst no-one'], timeout_s =1.5)
    Traceback (most recent call last):
    ...
    RuntimeError: test/slowoutput.py a longish string that interestst no-one killed with signal 15; output:
    'a longis'

    '''
    logging.debug(' '.join(args))
    if execute:
        if timeout_s is None:
            return subprocess.Popen(args,
                                    shell  = False,
                                    stdout = subprocess.PIPE,
                                    stdin  = subprocess.PIPE,
                                    stderr = stderr).communicate()[0]
        else:
            start_date = time.time()
            process = subprocess.Popen(args,
                shell  = False,
                stdout = subprocess.PIPE,
                stdin  = subprocess.PIPE,
                stderr = stderr)
            stdout = []
            out = ''
            while True:
                out = process.stdout.read(1)
                if out == '' and process.poll() != None:
                    break
                if out != '':
                    stdout.append(out)
                if time.time() - start_date > timeout_s:
                    logging.error('timeout after %6.3f s: terminating command %s ',
                                  timeout_s, ' '.join(args))
                    os.kill(process.pid, signal.SIGTERM)
                    raise RuntimeError('%s killed with signal %d; output:\n%r' %
                                       (' '.join(args), signal.SIGTERM,
                                        ''.join(stdout)))
            logging.debug('process.poll(): %r', process.poll())
            if process.poll() < 0:
                raise RuntimeError('%s killed with signal %d' %
                                   (' '.join(args), process.poll()))
            return ''.join(stdout)
    else:
        return ''



def add_circle(ax, radius, **kwargs):
    r'''
    '''
    n_points = 100
    phases  = arange(0.0,2*pi+pi/n_points, 2*pi/(n_points-1))
    x, y = cos(phases), sin(phases)
    return ax.plot(x*radius, y*radius, **kwargs)




def index_html(image_name, movie_name, reload_interval_s=60):
    r'''
    Makes the contents of the index.html file. Substitutes image_name
    and movie_name as source files in the IMG tags.
    
    **Paremeters**
    
    image_name : string
        'latest.jpg' or something similar.

    movie_name : string
        'latest-movie-0.gif' or something similar.

    reload_interval_s : int
        Number of seconds between automatic reloads.

    **Returns**
    
    A string containing the contents of index.html.

    **Examples**
    
    >>> index = index_html(image_name = 'latest-DE605.jpg', movie_name = 'latest.gif')
    >>> [line for line in index.split('\n') if '<img ' in line][-1]
    '        <center><img width="750px" src="latest-DE605.jpg"></img>&nbsp;<img width="750px" src="latest.gif"></img></center>'
    '''
    template = r'''<html>
  <head>
    <meta http-equiv="refresh" content="%(reload_interval_s)d">
    <link rel="shortcut icon" href="https://www.astron.nl/misc/favicon.ico" type="image/x-icon" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/q_extlinks/q_extlinks.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/aggregator/aggregator.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/node/node.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/system/defaults.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/system/system.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/system/system-menus.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/modules/user/user.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/cck/theme/content-module.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/filefield/filefield.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/nice_menus/nice_menus.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/q_incl/css/menu.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/cck/modules/fieldgroup/fieldgroup.css?f" />
    <link type="text/css" rel="stylesheet" media="all" href="https://www.astron.nl/sites/all/modules/views/css/views.css?f" />
    <link type="text/css" rel="stylesheet" media="print" href="https://www.astron.nl/sites/all/themes/astron/print.css?f" />

<link href="https://www.astron.nl/q_incl/portal/css/global.css" rel="stylesheet" type="text/css" />
<link href="https://www.astron.nl/q_incl/css/style.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 8]>
    <link href="/q_incl/css/style_ie.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if lt IE 7]>
    <link href="/q_incl/css/style_ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->



    <title>Lofar LIVE!</title>
  </head>
  <body>
    <div id="q_main_wrapper">

    <div id="q_header">
        <div id="q_logo">
          <div class="block block-block" id="block-block-1">
          <div class="content"><a href="https://www.astron.nl/" title="Astron Home"><img src="https://www.astron.nl/sites/astron.nl/files/logo.gif" alt="Astron, Astronomy institute" width="195" height="56" /></a> Netherlands Institute for Radio Astronomy
          </div>
         </div>
        </div>
    </div> <!-- q_header -->

    <div id="q_content">
    <div class="node">
    <div class="content">
    <!-- <h1> Lofar LIVE! </h1> -->
<!--    <p>A live display of the most recent all sky image, observed at long radio waves, with a LOFAR station. Blue indicates faint emission, red bright emission. The circle is the station's horizon.</p> -->
    <p>
        <center><img width="750px" src="%(image_name)s"></img>&nbsp;<img width="750px" src="%(movie_name)s"></img></center>
    </p>
    </div>
    </div>
    </div> <!-- q_content -->

  </div> <!-- q_main_wrapper -->
  </body>
</html>'''
    
    return template % {'image_name'        : image_name,
                       'movie_name'        : movie_name,
                        'reload_interval_s' : reload_interval_s}


def lofar_live_cep2(dir_name, field_name, subband, band, rcu_mode, num_pixels = 101, jpg_output=True, dpi=50, output_dir='/globaldata/lofarlive/', config_dir='/globaldata/lofarlive/'):
    r'''
    '''
    station, field = field_name[0:5].upper(), field_name[5:].upper()
    rcu_gains = ones((rcus_in_station(station_type(field_name)),), dtype=complex128)
    try:
        cal_header, cal_data = read_caltable(field_name, rcu_mode = rcu_mode, config_dir = config_dir)
        print(''.join(cal_header))
        rcu_gains = cal_data[subband, :]
    except IOError:
        print(sys.exc_info()[1])
        cal_header, cal_data = None, None

    mat, grid_l, grid_m  = compute_mapping_matrix(field_name,
                                                  subband,
                                                  band,
                                                  num_pixels = num_pixels,
                                                  config_dir = config_dir)

    specific_output_dir = os.path.join(output_dir, station+'C', 'images')
    try:
        os.makedirs(specific_output_dir)
    except OSError:
        print(sys.exc_info()[1])

    movie_names = [os.path.join(output_dir, 'latest-movie-0.gif'),
                   os.path.join(output_dir, 'latest-movie-1.gif')]

    while True:
        acm_file_names = [fn for fn in sorted(os.listdir(dir_name)) if fn[-7:] == 'xst.dat']
        for filename in acm_file_names:
            try:
                print(filename)
                gc.collect(True)
                filename_full = os.path.join(dir_name, filename)
                print(filename_full)
                img = make_maps_fista(filename_full, field_name, mat,
                                      grid_l, grid_m, num_pixels, rcu_gains,
                                      reg_factor=1.0e7)
                #img_clean = make_maps_fista(filename_full, field_name, mat,
                #                            grid_l, grid_m, num_pixels, rcu_gains)
                max_flux = img.max()
                print('Image peak   : ' + str(max_flux))
                print('Image shape  : ' + str(img.shape))
                if jpg_output:
                    fig = Figure(figsize=(18,18), dpi=dpi)
                else:
                    fig = figure(figsize=(18,18), dpi=dpi)
                extent = imshow_extent(grid_l, grid_m, num_pixels)
                print('Image extent: '+ str(extent))
                ax = fig.add_subplot(1, 1, 1)
                vmax=img[img != 0.0].mean() + img[img != 0.0].std()*6
                ax.imshow(img[:, ::-1],
                          extent = extent,
                          origin = 'lower',
                          vmax=vmax)
                date_str = filename.split('_xst.dat')[0]
                date = date_str[0:4]+'/'+date_str[4:6]+'/'+date_str[6:8]+' '+date_str[9:11]+':'+date_str[11:13]+':'+date_str[13:15]
                ax.set_title(field_name+' '+date+' UTC '+str(int(subband_freq_hz(subband, band)*1e-6+0.5))+' MHz',fontsize=45)
                print(date)
                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_xlabel('South', fontsize=45)
                ax.set_ylabel('East', fontsize=45)
                add_circle(ax, 1.0, color='white', linewidth=3)
                add_source_labels(ax, field_name, date, config_dir)
                if jpg_output:
                    output_name = os.path.join(specific_output_dir, station+'-sb'+str(subband)+'-'+date_str+'.jpg')
                    canvas_station = FigureCanvasAgg(fig)
                    canvas_station.print_figure(output_name, dpi = dpi)

                    output_name = os.path.join(output_dir, 'latest.jpg')
                    canvas = FigureCanvasAgg(fig)
                    canvas.print_figure(output_name, dpi = dpi)
                    try:
                        os.remove(filename_full)
                    except OSError:
                        print(sys.exc_info()[1])
                        
            except ValueError:
                print(str(sys.exc_info()[1]))
                pass
        if len(acm_file_names) > 0:
            image_names = sorted(glob.glob(os.path.join(specific_output_dir, '*-sb%d-*.jpg' % subband)))[-270::1]
            final_name = movie_names[0]
            print('Creating movie '+final_name)
            command = ['convert', '-delay', '10'] + image_names + [final_name]
            check_output(command, timeout_s = None)
            open(os.path.join(output_dir, 'index.html'), 'w').write(
                index_html(image_name        = 'latest.jpg',
                           movie_name        = os.path.split(final_name)[-1],
                           reload_interval_s = 200))
            movie_names = movie_names[::-1]
            print('done')

        time.sleep(1.0)


