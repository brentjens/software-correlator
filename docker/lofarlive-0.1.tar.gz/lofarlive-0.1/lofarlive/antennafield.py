r'''AntennaField.conf parser. First, the file needs to be tokenized. Here
    is a generic tokenizer:'''

import re
from numpy import array, prod
# try:
#     from collections import OrderedDict
# except ImportError:
#     OrderedDict = dict


def print_readably(list_of_instances):
    return [str(item) for item in list_of_instances]

class TokenDesc:
    regex     = r''
    converter = str
    def __init__(self, converter, regex):
        self.regex     = regex
        self.converter = converter



class Token:
    name     = ''
    text     = ''
    value    = None
    filename = ''
    lineno   = None
    colno    = None
    def __init__(self, name, text, value, filename, lineno, colno):
        self.name     = name
        self.text     = text
        self.value    = value
        self.filename = filename
        self.lineno   = lineno
        self.colno    = colno
    
    def __repr__(self):
        return r'''Token(name = %r, text = %r, value = %r,
      filename = %r, lineno = %r, colno = %r)''' %  \
                (self.name, self.text, self.value, self.filename,
                 self.lineno, self.colno)


    def __str__(self):
        return repr(self)



class ParseError(Exception):
    msg         = ''
    filename    = ''
    lineno      = -1
    colno       = -1
    expected    = None
    encountered = None
    text        = ''
    def __init__(self, msg, filename = '', lineno = -1, colno = -1,
                 expected = None, encountered = None, text = ''):
        self.msg         = msg
        self.filename    = filename
        self.lineno      = lineno
        self.colno       = colno
        self.expected    = expected
        self.encountered = encountered
        self.text        = text
        

    def __str__(self):
        return self.msg + """ in file \"%(filename)s\", line %(lineno)d, col %(colno)d:
Expected   : %(expected)s
Encountered: %(encountered)s (\"%(text)s\")
""" %  {'filename'   : self.filename,
        'lineno'     : self.lineno,
        'colno'      : self.colno,
        'expected'   : self.expected,
        'encountered': self.encountered,
        'text'       : self.text}



def identity(arg):
    return arg


def rest(sequence):
    return sequence[1:]


def first(sequence):
    if len(sequence) == 0:
        return None
    else:
        return sequence[0]    
    

def compile_tokens(tokens):
    return [(token_name, re.compile(token_desc.regex))
            for token_name,token_desc in tokens]


def read_file(filename, filter_fn=identity):
    lines = open(filename).readlines()
    return ''.join([filter_fn(line) for line in lines])


def remove_each(element, sequence, key=identity):
    return [x for x in sequence if key(x) is not element]


def token_match_length(match):
    return len(match.group(0))


def longest_match(possible_matches):
    matches = remove_each(None, possible_matches, key = lambda x:x[1])
    if matches == []:
        return (None, None)
    else:
        potential_matches = sorted(matches, key = lambda x:token_match_length(x[1]))
        longest = potential_matches[-1]
        return longest


def tokenize_once(string, start, compiled_tokens):
    return longest_match([(token, regex.match(string, start))
                          for token,regex in compiled_tokens])
        

def tokenize_file(filename, tokens):
    text            = read_file(filename)
    compiled_tokens = compile_tokens(tokens)
    line_number     = 1
    col_number      = 0
    filepos         = 0
    filesize        = len(text)
    found_tokens    = []
    while filepos < filesize:
        token, match = tokenize_once(text, filepos, compiled_tokens)
        if token is not None:
            matchlen = len(match.group(0))
            found_tokens += [Token(token,
                                   match.group(0),
                                   dict(tokens)[token].converter(match.group(0)),
                                   filename, line_number, col_number)]
            col_number += matchlen
            filepos    += matchlen
            if token in ['newline', 'comment']:
                line_number += 1
                col_number   = 1
        else:
            raise SyntaxError('invalid syntax',
                              (filename, line_number,  col_number,
                               text[filepos-col_number:text.find('\n', filepos)]))
    return found_tokens



#
# Specific stuff
#



TOKENS = [('float'        , TokenDesc( float, r'[+-]?(\d+\.\d*|\.\d+)(e[+-]?\d+)?')),
          ('whitespace'   , TokenDesc( str,   r'[ \t]+')),
          ('newline'      , TokenDesc( str,   r'\n|\r\n')),
          ('comment'      , TokenDesc( str,   r'#.*(\n|\r\n)')),
          ('integer'      , TokenDesc( int,   r'[+-]?\d+')),
          ('bracket_open' , TokenDesc( str,   r'\[')),
          ('bracket_close', TokenDesc( str,   r'\]')),
          ('multiply'     , TokenDesc( str,   r'x')),
          ('name'         , TokenDesc( str,   r'[a-zA-Z]+\w*'))]


class AntennaField(object):
    def __init__(self, field_name, centre, positions):
        self.field_name = field_name
        self.centre     = centre
        self.positions  = positions

    def __repr__(self):
        return "AntennaField(field_name=%r, centre=%r, positions=%r)" % \
                (self.field_name, self.centre, self.positions)
    def __str__(self):
        return repr(self)



class NormalVector(object):
    def __init__(self, field_name, direction):
        self.field_name = field_name
        self.direction  = direction

    def __repr__(self):
        return "NormalVector(field_name=%r, direction=%r)" % \
                (self.field_name, self.direction)



class RotationMatrix(object):
    def __init__(self, field_name, rotation_matrix):
        self.field_name = field_name
        self.rotation_matrix = rotation_matrix

    def __repr__(self):
        return "RotationMatrix(field_name=%r, rotation_matrix=%r)" % \
                (self.field_name, self.rotation_matrix)
        

def expect(token_names, token_list, filename):
    token = first(token_list)
    if token == None:
        raise ParseError('Unexpected end of file', expected=token_names, filename=filename)
    if first(token_list).name in token_names:
        return (first(token_list), rest(token_list))
    else:
        raise ParseError('Unexpected token',
                         filename=filename,
                         lineno=token.lineno,
                         colno=token.colno,
                         expected=token_names,
                         encountered=token.name,
                         text=token.text)


def parse_integer(tokens, filename):
    token, remaining = expect(['integer'], tokens, filename)
    return token.value, remaining

def parse_float(tokens, filename):
    token, remaining = expect(['integer', 'float'], tokens, filename)
    return (float(token.value), remaining)

def parse_open(tokens, filename):
    token, remaining = expect(['bracket_open'], tokens, filename)
    return token.value, remaining

def parse_close(tokens, filename):
    token, remaining = expect(['bracket_close'], tokens, filename)
    return token.value, remaining

def parse_name(tokens, filename):
    token, remaining = expect(['name'], tokens, filename)
    return token.value, remaining

def ignore_whitespace(tokens, filename):
    if tokens == []:
        return []
    elif first(tokens).name in ['newline', 'whitespace', 'comment']:
        return ignore_whitespace(rest(tokens), filename)
    else:
        return tokens


def parse_shape(tokens, filename):
    shape = []
    next_tokens  = ignore_whitespace(tokens, filename)
    num, next_tokens = parse_integer(next_tokens, filename)
    shape += [num]
    next_tokens  = ignore_whitespace(next_tokens, filename)
    while first(next_tokens).name != 'bracket_open':
        x, next_tokens = expect(['multiply', 'name'], next_tokens, filename)
        if x.text != 'x':
            raise ParseError('Unexpected token',
                             filename=filename,
                             lineno=x.lineno,
                             colno=x.colno,
                             expected=token_names,
                             encountered=x.name,
                             text=x.text)
        next_tokens = ignore_whitespace(next_tokens, filename)
        num, next_tokens = parse_integer(next_tokens, filename)
        shape += [num]
        next_tokens = ignore_whitespace(next_tokens, filename)
    return (shape, next_tokens)


def parse_array(tokens, filename):
    shape, next_tokens = parse_shape(tokens, filename)
    numbers     = []
    next_tokens = ignore_whitespace(next_tokens, filename)
    bracket, next_tokens = parse_open(next_tokens, filename)
    for i in range(prod(shape)):
        next_tokens      = ignore_whitespace(next_tokens, filename)
        num, next_tokens = parse_float(next_tokens, filename)
        numbers         += [num]
        ws, next_tokens  = expect(['whitespace', 'newline'], next_tokens, filename)
        next_tokens      = ignore_whitespace(next_tokens, filename)
    bracket, next_tokens = parse_close(next_tokens, filename)
    return (array(numbers).reshape(shape), next_tokens)
        

def parse_item(tokens, filename):
    name, next_tokens = parse_name(tokens, filename)
    next_tokens = ignore_whitespace(next_tokens, filename)
    if name == 'NORMAL_VECTOR':
        field_name, next_tokens = parse_name(next_tokens, filename)
        next_tokens = ignore_whitespace(next_tokens, filename)
        direction, next_tokens = parse_array(next_tokens, filename)
        return NormalVector(field_name, direction), next_tokens
    elif name == 'ROTATION_MATRIX':
        field_name, next_tokens      = parse_name(next_tokens, filename)
        next_tokens = ignore_whitespace(next_tokens, filename)
        rotation_matrix, next_tokens = parse_array(next_tokens, filename)
        return RotationMatrix(field_name, rotation_matrix), next_tokens
    elif name in ['HBA0', 'HBA1']:
        centre, next_tokens = parse_array(next_tokens, filename)
        return AntennaField(name, centre, None), next_tokens
    else:
        centre, next_tokens = parse_array(next_tokens, filename)
        next_tokens = ignore_whitespace(next_tokens, filename)
        positions, next_tokens = parse_array(next_tokens, filename)
        return AntennaField(name, centre, positions), next_tokens
        

def parse_antenna_field(filename):
    try:
        tokens = tokenize_file(filename, TOKENS)
        items  = []
        tokens = ignore_whitespace(tokens, filename)
        while tokens != []:
            item, tokens = parse_item(tokens, filename)
            items.append(item)
            tokens = ignore_whitespace(tokens, filename)
        return items
    except ParseError as error:
        print(error)


def parse_ihbadeltas(filename):
    try:
        tokens = tokenize_file(filename, TOKENS)
        items  = []
        tokens = ignore_whitespace(tokens, filename)
        name, next_tokens = parse_name(tokens, filename)
        if 'HBADeltas' != name:
            raise ParseError('Expected HBADeltas, not %s' % name,
                             filename=filename,
                             lineno=tokens[0].lineno,
                             colno=tokens[0].colno,
                             expected='HBADeltas',
                             encountered=name,
                             text=tokens[0].text)
        next_tokens = ignore_whitespace(next_tokens, filename)
        ant_pos, next_tokens  = parse_array(next_tokens, filename)
        return ant_pos
    except ParseError as error:
        print(error)
