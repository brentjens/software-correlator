r"""
This module contains an implementation of the Fast Iterative Soft
Thresholding Algorithm by Beck & Tebouille (2009). This version
attempts to compute an L1-regularized least squares solution to the problem

.. math:: \vec{d} = \mathrm{A}\vec{x}+\vec{\sigma},

where :math:`\vec{d}` contains the observations, the matrix
:math:`\mathrm{A}` is the model matrix, :math:`\vec{x}` contains the
unknown parameters, and :math:`\vec{\sigma}` is a noise
realization. All vectors as well as the matrix :math:`\mathrm{A}` are
*complex valued*.

The FISTA method implemented here tries to minimize

.. math::
   :nowrap: 

   \begin{eqnarray}
   F(\vec{x}) &=&  f(\vec{x}) + g(\vec{x}) \\
   f(\vec{x}) &=&  N^{-1}\left\|\left(\vec{d} - \mathrm{A}\vec{x}\right)\circ\frac{1}{\vec{\sigma}}\right\|^2_2 \\
   g(\vec{x}) &=& \lambda M^{-1} \left\| \vec{\gamma}\circ\sqrt{\vec{x}\circ\vec{x}^*} \right\|_1,
   \end{eqnarray}

where :math:`N` and :math:`M` are the number of complex data points in
:math:`\vec{d}` and the number of complex parameters in
:math:`\vec{x}`, respectively. The vector :math:`\vec{\gamma}`
contains relative weights of the parameters. For properly weighted
results, it should contain the inverse of the geometric sum of the
expected amplitude noise per complex parameter, and the expected
amplitude of that parameter:

.. math:: \gamma_i = 1/\sqrt{|\sigma_i|^2 + |p_i|^2},

with :math:`\vec{p}` containing the prior expected amplitude of each
parameter.

The user defines the problem by providing four items:

1) a function taking the complex vector :math:`\vec{x}` as a
   parameter, and returning a tuple containing the result of the first
   term as its first element, and the derivatives of the first term with
   respect to the complex parameters as its second element;

2) the real-valued vector :math:`\vec{\gamma}`;

3) the amount of regularization, :math:`\lambda`, typically of order one;

4) an optional first guess for :math:`\vec{x}`;

If the latter is not provided, the first guess will be set to :math:`1/\vec{\gamma}`.

The vector of derivatives is defined as:

.. math:: \frac{\partial f}{\partial x_i} = \frac{\partial f}{\partial \Re x_i} + \mathrm{i}\frac{\partial f}{\partial \Im x_i}.



**Example**

Here follows a small but meaningful example from radio astronomy:
Faraday rotation measure synthesis. When observing polarized radiation
from somewhere in the universe, the polarization angle of that
radiation is modified by the intervening magnetized plasma. The amount
of rotation is proportional to :math:`\phi\lambda^2`, where
:math:`\phi` is the so-called Faraday depth, given by

.. math:: \phi = 0.81\int_{r}^0 n_\mathrm{e} \vec{B}\cdot\mathrm{d}\vec{l},

and :math:`\lambda` is the wavelength.

There exists a Fourier relation between the intrinsic complex
polarization fraction :math:`f(\phi)=q(\phi)+\mathrm{i}u(\phi)` as a
function of Faraday depth, and the observed polarization as a function
of wavelength squared,

.. math:: p(\lambda^2) = \int_{-\infty}^{+\infty} f(\phi) \mathrm{e}^{2\mathrm{i}\phi\lambda^2}\ \mathrm{d}\phi.

In matrix form, this becomes

.. math:: \vec{p} = \mathrm{F} \vec{f},

where

.. math:: F_{ij}=\mathrm{e}^{2\mathrm{i}\lambda^2_i\phi_j}.


The derivatives of the first term in the minimization scheme is given
by

.. math:: \frac{\partial }{\partial f_j} N^{-1}\left\|\left(\vec{p} - \mathrm{F}\vec{f}\right)\circ\frac{1}{\vec{\sigma}}\right\|^2_2= -2 N^{-1} \left\lbrace\mathrm{F}^\dagger \left(\frac{\vec{p} - \mathrm{F} f}{\vec{\sigma}^2}\right)\right\rbrace_j.


We can now define a function to compute the matrix :math:`\mathrm{F}`:

>>> def matrix_F(lambda_squared, phi):
...     return exp(2j*lambda_squared[:,newaxis]*phi[newaxis,:])

Let's try out this function:

>>> F=matrix_F(arange(3), arange(-1,2.01,1))
>>> F.shape
(3, 4)
>>> F
array([[ 1.00000000+0.j        ,  1.00000000+0.j        ,
         1.00000000+0.j        ,  1.00000000+0.j        ],
       [-0.41614684-0.90929743j,  1.00000000+0.j        ,
        -0.41614684+0.90929743j, -0.65364362-0.7568025j ],
       [-0.65364362+0.7568025j ,  1.00000000+0.j        ,
        -0.65364362-0.7568025j , -0.14550003+0.98935825j]])

OK, that works. We should now simulate some data, based on a simple
model of :math:`f(\phi)`, and by adding some noise. We construct a
model consisting of three sources:

1) :math:`0.003-0.003\mathrm{i}` at :math:`\phi=-100`.
2) :math:`0.02+0\mathrm{i}` at :math:`\phi=40`;
3) :math:`0-0.02\mathrm{i}` at :math:`\phi=50`;

>>> phi_simulation = array([  -100.0,   40.0,     50.0])
>>> f_simulation   = array([0.003-0.003j, .02+0j, 0.0-0.02j])

We also define the :math:`\lambda^2` grid at which the observations
are conducted:

>>> lambda_squared = (299792458.0/arange(310e6, 370e6,0.6e6))**2

And a noise realization, which will have a noise in :math:`\phi` space
of the order of 0.1 per real/imaginary part.

>>> from numpy.random import normal
>>> N=len(lambda_squared)
>>> noise_level=0.001*sqrt(N-1)
>>> noise=normal(0.0, noise_level, (N,))+1j*normal(0.0, noise_level, (N,))
>>> simulated_F = matrix_F(lambda_squared, phi_simulation)
>>> simulated_p = dot(simulated_F, transpose(f_simulation))+noise
>>> len(simulated_p)
100

We now define the grid at which the spectrum reconstruction should happen:

>>> reconstruction_phi=arange(-300, 300.001,5)

And the function to provide to FISTA:

>>> def f_df_fn(f, F, FH, p, sigma,):
...     N = len(p)
...     return (((abs(p-dot(F,transpose(f)))/abs(sigma))**2).mean(),
...             -(2.0/float(N)/len(f))*dot(FH, transpose((p-dot(F,transpose(f)))/(abs(sigma)**2))))
>>> F  = matrix_F(lambda_squared, reconstruction_phi)
>>> FH = conj(transpose(F))
>>> reg_weights_uniform=ones(reconstruction_phi.shape)/(sqrt(0.001**2+(0.04/len(reconstruction_phi))**2))
>>> result=fista(f_df_fn, reg_weights_uniform, reg_factor=0.05,
...              x0=ones(reconstruction_phi.shape,dtype=complex128)*0.001,
...              args=(F, FH, simulated_p, array([noise_level+1j*noise_level]*N)),
...              max_iter=1000,
...              minimum_nullfrac=1.0-9.0/len(reconstruction_phi),
...              L0=1.0)
>>> len(result)
2
>>> len(result[0])
121
>>> prior_amps=zeros(reconstruction_phi.shape, dtype=float64)
>>> prior_amps[reconstruction_phi.tolist().index(-100.0)] = 0.005
>>> prior_amps[reconstruction_phi.tolist().index(+40.0)] = 0.03
>>> prior_amps[reconstruction_phi.tolist().index(+50.0)] = 0.03
>>> reg_weights_prior = 1.0/(sqrt(0.001**2+prior_amps**2))
>>> result_prior=fista(f_df_fn, reg_weights_prior, reg_factor=0.1,
...              x0=None,
...              args=(F, FH, simulated_p, array([noise_level+1j*noise_level]*N)),
...              max_iter=1000,
...              minimum_nullfrac=1.0-9.0/len(reconstruction_phi),
...              L0=1.0)

"""

from numpy import array,arange,exp,angle,sqrt,newaxis,conj,transpose,dot,zeros,ones,inner,complex128,float64,inf

from numpy.linalg import norm
import gc,sys


def make_negative_values_zero(x):
    r"""
Takes an array, and returns a copy of that array with all negative
values set to zero. It implements the following function:

.. math:: \left\lbrace x\right\rbrace_+ = \left\lbrace\begin{array}{ll} 0 & x < 0\\ x & x \geq 0\end{array}\right.

**Parameters**

x : numpy array of floats or ints
    The original.

**Returns**

A numpy array containing a copy of the input with negative values set
to zero.

**Examples**

>>> make_negative_values_zero(array([-2, -1.1, -1e-12, 0.0, 12.0, 24.0]))
array([  0.,   0.,   0.,   0.,  12.,  24.])

    """
    y=x.copy()
    y[y<0] = 0
    return y



def complex_signum(z):
    r"""
A complex valued replacement of the signum function, useful for
computing the derivative of :math:`|z|` with respect to its real and
imaginary parts. It computes

.. math:: \mathrm{e}^{\mathrm{i}\,\mathrm{arg}\,z}.

**Parameters**

z : (numpy array of) complex float
   Real floats are also allowed

**Examples**

>>> complex_signum(2.0)
(1+0j)
>>> abs(complex_signum(-100.0) - (-1+1.2246467991473532e-16j)) < 1e-16
True
>>> all((abs(complex_signum(array([2.+2j, 3.j, -1.+1j,-3.,-4.-4j,-6.j,1.-1j]))-
... array([  7.07106781e-01 +7.07106781e-01j,
...          6.12323400e-17 +1.00000000e+00j,
...         -7.07106781e-01 +7.07106781e-01j,
...         -1.00000000e+00 +1.22464680e-16j,
...         -7.07106781e-01 -7.07106781e-01j,
...          6.12323400e-17 -1.00000000e+00j,   7.07106781e-01 -7.07106781e-01j])))<1e-9)
True

    """
    return exp(1.j*angle(z))



def shrinkage_Talpha(x, thresholds):
    #return x-weights*complex_signum(x)
    result=x.copy()
    result[abs(x) - thresholds < 0.0]=0.0
    return result #complex_signum(x)*make_negative_values_zero(abs(x) - thresholds)



def fn_pl_fn(gamma, reg_factor):
    def fn_pl(l, x, df_dx):
        M=len(df_dx)
        return shrinkage_Talpha(x-df_dx/l, gamma*reg_factor/l/M)
    return fn_pl




def fn_Ql_fn(f_df_fn, reg_term_fn):
    def fn_Ql(l, x, y):
        fy, df_dy = f_df_fn(y)
        gx        = reg_term_fn(x)
        return fy+inner(conj(x-y), df_dy)+0.5*l*(abs(x-y)**2).sum() + gx
    return fn_Ql




def fn_F_fn(f_df_fn, reg_term_fn):
    def fn_F(x):
        return f_df_fn(x)[0]+reg_term_fn(x)
    return fn_F



def new_stepsize_fn(fn_F, fn_Ql, fn_pl, eta):
    def new_stepsize(l0, y, df_dy):
        i = 0
        l_trial=l0
        while True:
            pl_y = fn_pl(l_trial, y, df_dy)
            if fn_F(pl_y) <= fn_Ql(l_trial, pl_y, y):
                return l_trial
            else:
                l_trial*= eta
                pass
    return new_stepsize
    


def regularization_term_fn(reg_factor, reg_weights):
    def reg_term(x):
        return abs(x*reg_weights).mean()*reg_factor
    return reg_term


def f_df_with_args_fn(f_df_fn, args):
    def f_df(x):
        return f_df_fn(x, *args)
    return f_df



def no_change(a, b, c, epsilon):
    return abs(a-b)/abs(b) < epsilon and abs(c-b)/abs(b) < epsilon







def halting_criterion_reached(k, min_iter, max_iter, fys, Fs, nullfrac, minimum_nullfrac, L, L0, epsilon=1e-7):
    if k <= min_iter:
        return (False, -1)
    if k >= max_iter:
        return (True,-1)
    if k < 3:
        return (False,-1)

    # No progress anymore
    if no_change(fys[k-3], fys[k-2], fys[k-1], epsilon) and no_change(Fs[k-3], Fs[k-2], Fs[k-1], epsilon) and no_change(nullfrac[k-3], nullfrac[k-2], nullfrac[k-1],epsilon):
        return (True, -1)

    if Fs[k-3] >= Fs[k-2] <= Fs[k-1] and nullfrac[k-2] >= minimum_nullfrac:
        return (True,-2)
    
    if nullfrac[k-3] >= minimum_nullfrac and nullfrac[k-3]<=nullfrac[k-2]>=nullfrac[k-1] and L[k] > L0:
        if k >= 3 and fys[k-3] <= fys[k-2] <= fys[k-1] and Fs[k-3] <= Fs[k-2] <= Fs[k-1]:
            #We are diverging
            return (True, -3)
    return (False,0)






def fista(f_df_fn, reg_weights, reg_factor, x0=None, args=(), L0=1.0, eta=100.0, max_iter=100, min_iter=0, minimum_nullfrac=0.1, epsilon=1e-7, verbose=0):
    reg_term =regularization_term_fn(reg_factor=reg_factor,
                                     reg_weights=reg_weights)
    f_df         = f_df_with_args_fn(f_df_fn, args)
    fn_F         = fn_F_fn(f_df, reg_term)
    fn_Ql        = fn_Ql_fn(f_df, reg_term)
    fn_pl        = fn_pl_fn(reg_weights, reg_factor)
    new_stepsize = new_stepsize_fn(fn_F, fn_Ql, fn_pl, eta)
    
    x=None
    if x0 is None:
        x=(1.0/reg_weights)+0.0j
    else:
        x=x0.copy()
        pass
    x_previous=x.copy()
    y=x.copy()
    t_previous=1.0
    L=[L0]
    ys=[y]
    fys=[]
    Fs=[]
    nullfrac=[]
    for k in range(1,max_iter+1):
        fy, df_dy = f_df(y)
        rt=reg_term(y)
        fys.append(fy)
        Fs.append(fy+rt)
        #L.append(L0)
        L.append(new_stepsize(L[k-1], y, df_dy))
        nullfrac.append((y==0.0).mean())
        if verbose >= 1:
            print(k, fys[k-1], Fs[k-1], L[k], nullfrac[k-1])
            pass
        stop,which_one = halting_criterion_reached(k, min_iter, max_iter, fys, Fs, nullfrac, minimum_nullfrac, L, L0,epsilon)
        if stop:
            if verbose >= 2:
                print(repr(ys[k+which_one]))
                pass
            return (ys[k+which_one], ys)
        
        x=fn_pl(L[k], y, df_dy)
        t=(1+sqrt(1+4*t_previous**2))/2.0
        y=x+((t_previous-1)/t)*(x-x_previous)
        ys.append(y)
        t_previous=t
        x_previous=x.copy()
        pass
    return (y, ys)







def fista_matrix_fixed(A, b, epsilon, max_iter, x0=None, L0=1.0, reg_factor=None, prior_vector=None, output_is_real=False, require_positivity=False, lfactor=1e4, verbose=False):
    Ah=conj(transpose(A))
    
    def soft_threshold(x, threshold):
        destroy=abs(x) < threshold
        r=x-threshold*exp(1j*angle(x))
        r[destroy] = 0.0
        return r
    
    def f(x, pw, residuals, l):
        return norm(pw*x,1)*l + norm(residuals, 2)**2

    def df_dx(residuals):
        return -2*dot(Ah,residuals)
    
    pw=1.0
    if prior_vector is not None:
        pw=1/prior_vector
    
    x  = x0
    if x is None:
        x = dot(Ah, b)
        x*= abs(b).max()/abs(x.sum())
        if output_is_real:
            x=x.real
        pass
    
    L=L0
    lambda_limit= reg_factor
    if reg_factor is None:
        lambda_limit = 0.99*L*norm(x,inf)

    eta=0.3
    lmbd=lfactor*lambda_limit
    
    eps=1e3*epsilon

    N  = len(x)
    yk = zeros(x.shape, dtype=x.dtype)
    xk = zeros(x.shape, dtype=x.dtype)

    tk = 1.0

    res        = b-dot(A, x)
    if verbose:
        print(abs(b).max(), abs(x).max(), abs(res).max())
    f_previous = f(yk, pw, res, lmbd)
    if verbose:
        print('%r: %5.2f  %6r '%(-1, f_previous, 0.0))
        print(lmbd)
        print('%6s: %12s  %12s  %12s  %12s'%('Iter.', 'f_k', 'diff', 'max(res)', 'max(grad)'))
    mask=1.0
    try:
        for i in range(max_iter):
            grad   = df_dx(res)
            
            back_tracking = True
            while back_tracking:
                xk_new = soft_threshold(yk - (1./L)*grad, lmbd*pw/L)*mask
                if output_is_real:
                    xk_new = xk_new.real
                    if require_positivity:
                        xk_new [xk_new<0]=0.0
                resxk  = b - dot(A, xk_new)

                FF   = f(xk_new, pw, resxk, lmbd)
                QPL  = norm(res,2)**2
                QPL += inner(conj(xk_new-yk), grad)
                QPL += 0.5*L*norm(xk_new-yk,2)**2 
                QPL += norm(xk_new*pw,1)*lmbd
                
                if FF <= QPL.real:
                    back_tracking=False
                else:
                    L=L*sqrt(2)
                    if L==inf:
                        return yk
                    pass
                pass
            
            tk_new = 0.5*(1+sqrt(1+4*tk**2))
            yk     = xk_new+((tk-1)/tk_new)*(xk_new - xk) ## deviates from NESTA test
            if output_is_real:
                yk=yk.real

            xk     = xk_new.copy()

            res    = b - dot(A, yk)
            fk     = f(yk, pw, res, lmbd)

            normalized_diff = abs(fk-f_previous)/f_previous
            if verbose:
                print('%6r: %.2e  %.2e  %.2e  %.2e  %.2e  %.2e  %.2e  %4.1f%%'%(i, norm(res,2)**2/len(b), fk/len(b), normalized_diff, abs(res).max(), norm(grad,inf), lmbd, L, (yk==0.0).mean()*100.0))
        
            f_previous      = fk
            if normalized_diff < eps:
                if lmbd == lambda_limit:
                    return yk
                else:
                    L=0.25*(L+3*L0)
                    lmbd = max(lmbd*eta, lambda_limit)
                    if lmbd==lambda_limit:
                        eps=epsilon
                    pass
                pass

            pass
    except KeyboardInterrupt:
        pass
    return yk
