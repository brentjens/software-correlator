r'''
Conversion from J2000 to ITRF. The precession is computed using
the formalism described in the Astronomical Almanac 2008, pages
B28--B31. First the ra and dec must be converted to \cl{cartesian}
coordinates. The positive $x$ axis points through ($\alpha =
0^\mathrm{h}$, $\delta=0\degr$), the positive $y$ axis through
($\alpha=6^\mathrm{h}$, $\delta=0\degr$), and the positive $z$ axis
through the NCP.

'''

from numpy import array, sin, cos, pi, sign, sqrt, arctan2, dot
import ephem

ARCSEC                = pi/(180*3600.0)
PRECESS_EPSILON_0_RAD = 84381.448 * ARCSEC


def gmst(date):
    r'''
    Computes greenwich mean sidereal time at ``date``

    **Parameters**

    date : ephem.Date
        UTC date for which the GMST should be computed..    

    **Returns**
    
    ephem.Angle 

    **Examples**
    
    >>> '%.7f' % float(gmst('2012/12/11 11:35:00'))
    '4.4390301'
    '''
    pos_00           = ephem.Observer()
    pos_00.lat       = 0.0
    pos_00.long      = 0.0
    pos_00.elevation = 0.0
    pos_00.date      = date
    return pos_00.sidereal_time()



def cartesian_from_spherical(lon_rad, lat_rad):
    r'''
    Convert spherical longitude and latitude to cartesian
    coordinates. Longitude is measured positive in the same direction
    as right ascension is.

    **Parameters**

    lon_rad : float
        longitude in radians.

    lat_rad : float
        latitude in radians.

    **Examples**
    
    >>> cartesian_from_spherical(0, 0)
    array([ 1.,  0.,  0.])
    >>> cartesian_from_spherical(0, +pi/2)
    array([  6.12323400e-17,   0.00000000e+00,   1.00000000e+00])
    >>> cartesian_from_spherical(+pi/2, 0)
    array([  6.12323400e-17,   1.00000000e+00,   0.00000000e+00])
    >>> cartesian_from_spherical(+pi, 0)
    array([ -1.00000000e+00,   1.22464680e-16,   0.00000000e+00])
    >>> cartesian_from_spherical(-pi, 0)
    array([ -1.00000000e+00,  -1.22464680e-16,   0.00000000e+00])
    >>> cartesian_from_spherical(-pi/2, 0)
    array([  6.12323400e-17,  -1.00000000e+00,   0.00000000e+00])
    >>> cartesian_from_spherical(0, -pi/2)
    array([  6.12323400e-17,   0.00000000e+00,  -1.00000000e+00])
    
    '''
    lon = lon_rad
    lat = lat_rad

    return array([cos(lat)*cos(lon), cos(lat)*sin(lon), sin(lat)])



def spherical_from_cartesian(xyz):
    r'''
    Convert cartesian coordinates to spherical longitude and latitude.

    **Parameters**
    
    xyz : sequence of floats
        The cartesian coordinates X, Y, and Z.

    **Returns**

    A tuple (lon_rad, lat_rad)

    **Examples**

    >>> def prad(lon_lat):
    ...     return '%.5f %.5f' % lon_lat
    >>> print(prad(spherical_from_cartesian([ 1,  0,  0])))
    0.00000 0.00000
    >>> print(prad(spherical_from_cartesian([-1,  0,  0])))
    3.14159 0.00000
    >>> print(prad(spherical_from_cartesian([ 0,  1,  0])))
    1.57080 0.00000
    >>> print(prad(spherical_from_cartesian([ 0, -1,  0])))
    -1.57080 0.00000
    >>> print(prad(spherical_from_cartesian([ 0,  0,  1])))
    0.00000 1.57080
    >>> print(prad(spherical_from_cartesian([ 0,  0, -1])))
    0.00000 -1.57080
    >>> print(prad(spherical_from_cartesian([ 1, 1,  2**0.5])))
    0.78540 0.78540

    '''
    x_m, y_m, z_m = tuple(xyz)
    radius = sqrt(x_m**2 + y_m**2)
    if radius <= 0.0:
        return (0.0, sign(z_m)*pi/2.0)
    lon_rad = arctan2(y_m, x_m)
    lat_rad = arctan2(z_m, radius)

    return (lon_rad, lat_rad)



def precess_t(julian_date_days):
    r'''
    Compute the Julian Date in centuries since J2000.0.

    To compute the precession rotation matrix $\mathrm{P}$ of a
    certain epoch, a few slowly varying angles must be defined. In the
    Astronomical Almanac, these angles are given as a function of
    
    \begin{equation}
    T = (JD_\mathrm{TT} - 2\,451\,545.0)/36\,525.
    \end{equation}
    
    Because precession is a slow, long term effect, the difference
    between TT and UTC is ignored.

    **Parameters**
    
    julian_date_days : float
        Julian date in days.

    **Returns**

    A float.

    **Examples**

    >>> precess_t(2451545.0)
    0.0
    >>> precess_t(ephem.julian_date('2008/01/01 12:00:00'))
    0.08
    >>> precess_t(ephem.julian_date('2008/07/02 03:00:00'))
    0.085
    '''
    return  (julian_date_days - 2451545.0) / 36525.0
    


def precess_psi_a(t_centuries):
    r'''
    Parameter $\Psi_\mathrm{A}$. The accuracy of this expression is
    about 20 mas in psi.

    **Parameters**

    t_centuries : float
        The date as computed by precess_t().

    **Returns**

    A float

    **Examples**
    
    >>> precess_psi_a(0.0)
    0.0
    >>> '%.7f' % precess_psi_a(1.0)
    '0.0244220'
    >>> '%.7f' % precess_psi_a(8.5e-2)
    '0.0020763'
    '''
    t_c    = t_centuries
    arcsec = pi/(180.0*3600)
    return (0.0 + t_c*(5038.47875 + t_c*(-1.07259 + t_c*(-0.001147))))*arcsec



def precess_omega_a(t_centuries, epsilon_0_rad = PRECESS_EPSILON_0_RAD):
    r'''
    Parameter $\omega_\mathrm{A}$.

    **Parameters**

    t_centuries : float
        The date as computed by precess_t().

    **Returns**

    A float.

    **Examples**

    >>> '%.9f' % abs(precess_omega_a(0.0) - PRECESS_EPSILON_0_RAD)
    '0.000000000'
    >>> '%.7f' % precess_omega_a(8.5e-2)
    '0.4090928'
    '''
    t_c    = t_centuries
    arcsec = pi/(180.0*3600)
    return epsilon_0_rad + t_c*(-0.02524 + t_c*(0.05127 + t_c*(-0.007726)))*arcsec



def precess_chi_a(t_centuries):
    r'''
    Parameter $\chi_\mathrm{A}$.

    **Parameters**

    t_centuries : float
        The date as computed by precess_t().

    **Returns**

    A float.

    **Examples**

    >>> '%.9f' % precess_chi_a(0.0)
    '0.000000000'
    >>> '%.8f' % precess_chi_a(8.5e-2)
    '0.00000427'

    '''
    t_c    = t_centuries
    arcsec = pi/(180.0*3600)
    return t_c*(10.5526 + t_c*(-2.38064 + t_c*(-0.001125)))*arcsec



def precess_matrix(date):
    r'''

    Compute a 3X3 matrix to precess coordinates from J2000 to ``date``.
    
    **Parameters**

    date : ephem.Date
        UTC date for which to compute the precession matrix.

    **Returns**

    A 3x3 numpy.array of floats.

    **Examples**

    >>> precess_matrix('2008/07/02 03:00:00')
    array([[  9.99997853e-01,  -1.90068061e-03,  -8.25895106e-04],
           [  1.90068062e-03,   9.99998194e-01,  -7.74492607e-07],
           [  8.25895086e-04,  -7.95271876e-07,   9.99999659e-01]])
    '''
    t_c     = precess_t(ephem.julian_date(date))
    eps_0   = PRECESS_EPSILON_0_RAD
    psi_a   = precess_psi_a(t_c)
    omega_a = precess_omega_a(t_c)
    chi_a   = precess_chi_a(t_c)

    c1, s1 = cos(   eps_0), sin(   eps_0)
    c2, s2 = cos(  -psi_a), sin(  -psi_a)
    c3, s3 = cos(-omega_a), sin(-omega_a)
    c4, s4 = cos(   chi_a), sin(   chi_a)
    
    return array([[c4*c2 - s2*s4*c3,
                   c4*s2*c1 + s4*c3*c2*c1 - s1*s4*s3,
                   c4*s2*s1 + s4*c3*c2*s1 + c1*s4*s3],
                  
                  [-s4*c2 - s2*c4*c3,
                    c4*c3*c2*c1 - s4*s2*c1 - s1*c4*s3,
                    c4*c3*c2*s1 + c1*c4*s3 - s4*s2*s1],

                  [s2*s3,
                   -s3*c2*c1 - s1*c3,
                   c3*c1 - s3*c2*s1]])


def precess_to_epoch(j2000_ra_rad, j2000_dec_rad, date):
    r'''
    Precess J2000 ra and dec to ``date``.

    **Paremeters**

    j2000_ra_rad : float
        J2000 right ascension in radians.

    j2000_ra_dec : float
        J2000 declination in radians.

    date : ephem.Date
        UTC date for which to compute the precession matrix.

    **Returns**

    A tuple of two floats (date_ra_rad, date_dec_rad).

    **Examples**

    >>> 'ra: %.7f; dec: %.7f' %  precess_to_epoch(4.5, 1.0, '2008/07/02 03:00:00')
    'ra: 4.5006435; dec: 0.9998262'
    '''
    j2000_xyz = cartesian_from_spherical(lon_rad = j2000_ra_rad,
                                         lat_rad = j2000_dec_rad)
    date_xyz  = dot(precess_matrix(date), j2000_xyz)
    date_ra_rad, date_dec_rad = spherical_from_cartesian(date_xyz)
    if date_ra_rad < 0.0:
        date_ra_rad += 2*pi
    return (date_ra_rad, date_dec_rad)





def itrf_from_topo_ra_dec(topo_ra_rad, topo_dec_rad, date):
    r'''
    Convert topo (precessed) ra and dec to ITRF cartesian coordinates.

    **Parameters**
    
    topo_ra_rad : float
        RA in radians.

    topo_dec_rad : float
        Dec in radians.

    date : ephem.Date
        UTC date for which to compute the precession matrix.

    **Returns**
    
    A numpy.array of length 3.

    **Examples**

    >>> None
    '''
    greenwich_angle = topo_ra_rad - float(gmst(date))
    itrf_x = cos(greenwich_angle)*cos(topo_dec_rad)
    itrf_y = sin(greenwich_angle)*cos(topo_dec_rad)
    itrf_z = sin(topo_dec_rad)
    
    return array([itrf_x, itrf_y, itrf_z])
    
